extends CharacterBody3D

signal died
var health := 100.0
var target
var speed := 3.0
var attack_timer := 0.0
var think_timer := 0.0
var wander_dir := Vector3.ZERO
var gravity := 22.0

func _ready() -> void:
    var body := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.43
    mesh.height = 1.8
    body.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.48, 0.12, 0.09)
    body.material_override = mat
    body.position.y = 0.9
    add_child(body)
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.43
    shape.height = 1.8
    col.shape = shape
    col.position.y = 0.9
    add_child(col)
    speed = randf_range(2.2, 3.8)

func _physics_process(delta: float) -> void:
    if health <= 0:
        return
    if not is_instance_valid(target) or float(target.get("health")) <= 0:
        velocity = Vector3.ZERO
        return
    var to_player: Vector3 = target.global_position - global_position
    to_player.y = 0
    var distance := to_player.length()
    var direction := Vector3.ZERO
    if distance < 55:
        direction = to_player.normalized()
        look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)
        attack_timer -= delta
        if distance < 24 and attack_timer <= 0:
            target.call("take_damage", 4.0)
            attack_timer = 1.1
    else:
        think_timer -= delta
        if think_timer <= 0:
            wander_dir = Vector3(randf_range(-1,1), 0, randf_range(-1,1)).normalized()
            think_timer = randf_range(2,5)
        direction = wander_dir
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    move_and_slide()
    if global_position.y < -10:
        take_damage(health)

func take_damage(amount: float) -> void:
    if health <= 0:
        return
    health = max(0.0, health - amount)
    if health <= 0:
        died.emit()
        queue_free()
