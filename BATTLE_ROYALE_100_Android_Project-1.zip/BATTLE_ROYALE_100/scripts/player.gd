extends CharacterBody3D

var health := 100.0
var speed := 8.0
var gravity := 22.0
var fire_held := false
var fire_timer := 0.0
var third_person := true
var mobile := {}
var yaw := 0.0
var pitch := -0.12
var camera: Camera3D
var pivot: Node3D
var muzzle: Node3D
var hit_flash := 0.0

func _ready() -> void:
    _build_body()
    _build_camera()
    _build_collision()
    for a in ["move_forward","move_back","move_left","move_right"]:
        mobile[a] = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _build_body() -> void:
    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.9
    body.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.28, 0.48)
    body.material_override = mat
    body.position.y = 0.95
    add_child(body)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.28
    head.mesh = sphere
    var hm := StandardMaterial3D.new()
    hm.albedo_color = Color(0.72, 0.55, 0.4)
    head.material_override = hm
    head.position.y = 2.05
    add_child(head)

func _build_collision() -> void:
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.9
    col.shape = shape
    col.position.y = 0.95
    add_child(col)

func _build_camera() -> void:
    pivot = Node3D.new()
    pivot.position.y = 1.55
    add_child(pivot)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 75
    pivot.add_child(camera)
    _set_camera_position()

func _set_camera_position() -> void:
    if third_person:
        camera.position = Vector3(0, 0.55, 5.5)
        camera.rotation = Vector3(pitch, 0, 0)
    else:
        camera.position = Vector3(0, 0.08, -0.35)
        camera.rotation = Vector3(pitch, 0, 0)

func _physics_process(delta: float) -> void:
    if health <= 0:
        return
    var forward := Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
    var side := Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    if mobile.get("move_forward", false): forward += 1
    if mobile.get("move_back", false): forward -= 1
    if mobile.get("move_right", false): side += 1
    if mobile.get("move_left", false): side -= 1
    var direction := (global_transform.basis * Vector3(side, 0, -forward)).normalized()
    if direction.length() > 0:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
    else:
        velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
        velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = 8.0
    move_and_slide()
    fire_timer -= delta
    if fire_held and fire_timer <= 0:
        shoot()
        fire_timer = 0.22
    if global_position.y < -10:
        health = 0

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        look_by_drag(event.relative)
    if event.is_action_pressed("view_toggle"):
        toggle_view()
    if event.is_action_pressed("fire"):
        fire_held = true
    if event.is_action_released("fire"):
        fire_held = false
    if event.is_action_pressed("jump") and is_on_floor():
        velocity.y = 8.0

func look_by_drag(delta: Vector2) -> void:
    yaw -= delta.x * 0.004
    pitch = clamp(pitch - delta.y * 0.003, -1.0, 0.65)
    rotation.y = yaw
    pivot.rotation.y = 0
    _set_camera_position()

func toggle_view() -> void:
    third_person = not third_person
    _set_camera_position()

func set_mobile_action(action: String, pressed: bool) -> void:
    mobile[action] = pressed

func set_fire(pressed: bool) -> void:
    fire_held = pressed

func request_jump() -> void:
    if is_on_floor():
        velocity.y = 8.0

func shoot() -> void:
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z * 180.0)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit and hit.collider.has_method("take_damage"):
        hit.collider.take_damage(34.0)

func take_damage(amount: float) -> void:
    health = max(0.0, health - amount)
