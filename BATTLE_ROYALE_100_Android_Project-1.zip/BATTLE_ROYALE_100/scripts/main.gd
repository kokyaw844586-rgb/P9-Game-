extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
var player
var enemies: Array = []
var hud: CanvasLayer
var status_label: Label
var enemy_count := 99
var game_over := false

func _ready() -> void:
    randomize()
    _make_environment()
    _make_ground()
    _make_cover()
    _make_player()
    _make_enemies()
    _make_hud()

func _make_environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.12, 0.32, 0.58)
    sky_mat.sky_horizon_color = Color(0.72, 0.82, 0.91)
    sky_mat.ground_bottom_color = Color(0.12, 0.16, 0.12)
    sky_mat.ground_horizon_color = Color(0.35, 0.42, 0.32)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.86)
    env.ambient_light_energy = 0.7
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.3
    sun.shadow_enabled = true
    add_child(sun)

func _make_ground() -> void:
    var ground := StaticBody3D.new()
    ground.name = "Ground"
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(260, 260)
    mesh.mesh = plane
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.19, 0.34, 0.16)
    mat.roughness = 1.0
    mesh.material_override = mat
    ground.add_child(mesh)
    var shape_node := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(260, 1, 260)
    shape_node.shape = shape
    shape_node.position.y = -0.55
    ground.add_child(shape_node)
    ground.position.y = -0.5
    add_child(ground)

func _make_cover() -> void:
    for i in range(45):
        var tree := Node3D.new()
        var x := randf_range(-115, 115)
        var z := randf_range(-115, 115)
        if Vector2(x, z).length() < 13:
            x += 24
        tree.position = Vector3(x, 0, z)
        var trunk := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = 0.35
        cyl.bottom_radius = 0.5
        cyl.height = 3.0
        trunk.mesh = cyl
        var bark := StandardMaterial3D.new()
        bark.albedo_color = Color(0.25, 0.13, 0.07)
        trunk.material_override = bark
        trunk.position.y = 1.5
        tree.add_child(trunk)
        var crown := MeshInstance3D.new()
        var cone := SphereMesh.new()
        cone.radius = randf_range(1.8, 2.8)
        cone.height = 4.0
        crown.mesh = cone
        var leaves := StandardMaterial3D.new()
        leaves.albedo_color = Color(0.08, randf_range(0.22, 0.38), 0.09)
        crown.material_override = leaves
        crown.position.y = 4.0
        tree.add_child(crown)
        add_child(tree)
    for i in range(18):
        var building := StaticBody3D.new()
        var box := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(randf_range(5, 9), randf_range(3, 5), randf_range(5, 9))
        box.mesh = bm
        var wall := StandardMaterial3D.new()
        wall.albedo_color = Color(0.48, 0.43, 0.34)
        box.material_override = wall
        building.add_child(box)
        var col := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = bm.size
        col.shape = bs
        building.add_child(col)
        building.position = Vector3(randf_range(-95,95), bm.size.y/2, randf_range(-95,95))
        add_child(building)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.name = "Player"
    player.position = Vector3(0, 1.2, 0)
    add_child(player)

func _make_enemies() -> void:
    for i in range(enemy_count):
        var enemy := CharacterBody3D.new()
        enemy.set_script(EnemyScript)
        enemy.name = "Enemy_%03d" % (i + 1)
        var angle := TAU * float(i) / float(enemy_count)
        var radius := randf_range(28, 112)
        enemy.position = Vector3(cos(angle) * radius, 1.0, sin(angle) * radius)
        enemy.target = player
        enemy.died.connect(_on_enemy_died)
        add_child(enemy)
        enemies.append(enemy)

func _make_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    status_label = Label.new()
    status_label.position = Vector2(18, 14)
    status_label.add_theme_font_size_override("font_size", 22)
    status_label.add_theme_color_override("font_color", Color.WHITE)
    hud.add_child(status_label)
    _update_status()
    var help := Label.new()
    help.text = "ဘယ်ဘက်: ရွေ့ရန်   ညာဘက်: ကြည့်ရန်   FIRE: ပစ်ရန်   VIEW: မြင်ကွင်းပြောင်း"
    help.position = Vector2(18, 48)
    help.add_theme_font_size_override("font_size", 15)
    help.add_theme_color_override("font_color", Color.WHITE)
    hud.add_child(help)
    _add_controls()

func _add_controls() -> void:
    _make_button("▲", Vector2(100, -160), "move_forward")
    _make_button("▼", Vector2(100, -55), "move_back")
    _make_button("◀", Vector2(45, -108), "move_left")
    _make_button("▶", Vector2(155, -108), "move_right")
    _make_button("ပစ်", Vector2(-100, -110), "fire")
    _make_button("ခုန်", Vector2(-205, -55), "jump")
    _make_button("မြင်ကွင်း", Vector2(-215, -160), "view")
    var look := Control.new()
    look.name = "LookArea"
    look.set_anchors_preset(Control.PRESET_FULL_RECT)
    look.mouse_filter = Control.MOUSE_FILTER_PASS
    look.gui_input.connect(_on_look_input)
    hud.add_child(look)
    # Keep look area behind buttons.
    hud.move_child(look, 0)

func _make_button(label_text: String, offset: Vector2, action: String) -> void:
    var b := Button.new()
    b.text = label_text
    b.custom_minimum_size = Vector2(76, 64)
    b.add_theme_font_size_override("font_size", 18)
    b.modulate = Color(1, 1, 1, 0.78)
    b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    b.position = offset
    b.button_down.connect(func(): _button_action(action, true))
    b.button_up.connect(func(): _button_action(action, false))
    hud.add_child(b)

func _button_action(action: String, pressed: bool) -> void:
    if action == "view":
        if pressed:
            player.toggle_view()
        return
    if action == "fire":
        player.set_fire(pressed)
    elif action == "jump":
        if pressed:
            player.request_jump()
    else:
        player.set_mobile_action(action, pressed)

func _on_look_input(event: InputEvent) -> void:
    if event is InputEventScreenDrag:
        if event.position.x > get_viewport().get_visible_rect().size.x * 0.42:
            player.look_by_drag(event.relative)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        player.look_by_drag(event.relative)

func _on_enemy_died() -> void:
    _update_status()

func _update_status() -> void:
    var alive := 0
    for e in enemies:
        if is_instance_valid(e) and e.health > 0:
            alive += 1
    if status_label:
        status_label.text = "BATTLE ROYALE 100   |   ရန်သူကျန်: %d   |   အသက်: %d" % [alive, int(player.health) if is_instance_valid(player) else 100]
